/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FlyWarII.Controller;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import FlyWarII.View.Client;

/**
 *
 * @author D3--
 */
public class Game {
    
    
    public static void main(String args[]) throws Exception
    {
        //-------------------------------------------------
        final Client theView = new Client();
        theView.setVisible(true);
        //-------------------------------------------------
        try
        {
            Registry reg = LocateRegistry.getRegistry("127.0.0.1", 1099);
            final GameI obj = (GameI)Naming.lookup("Server");
            //--------------------------------
            String username = "";
            do
            {
                username = theView.showLoginBox();
                if (username == null)
                    System.exit(0);
            }while("".equals(username) || !obj.isValid(username));
            //--------------------------------
            final String fusername = username;
            
            
            
            class RemindTask extends TimerTask
            {
                @Override
                public void run()
                {
                    try
                    {
                        //------------------------------------------------------
                        if (theView.isTerminated())
                        {
                            obj.removePlayer(fusername);
                            System.exit(0);
                        }
                        if (obj.isKilled())
                        {
                            theView.makeVisible();
                        }
                        else
                        {
                            theView.makeInvisible();
                            if (theView.getClickStatus())
                            {
                                int id = theView.getId();

                                obj.update(fusername, id);
                                theView.flipClickStatus();
                            }
                            else
                            {
                                int temp_xfa = obj.getxfa();
                                int temp_yfa = obj.getyfa();

                                theView.setId(obj.getId());
                                theView.moveFly(temp_xfa, temp_yfa);
                                theView.updateScore(obj.showScores());
                            }

                            
                        }
                        //------------------------------------------------------
                    }catch (Exception ex) {
                        Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            
            Timer timer = new Timer();
            timer.schedule(new RemindTask(), 0, 50);
            
            
            //--------------------------------
        }catch (Exception e)
        {
            System.out.println(e);
        }
    }
    
    
    
}