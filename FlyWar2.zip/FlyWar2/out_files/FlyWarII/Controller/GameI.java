/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FlyWarII.Controller;

import java.rmi.Remote;

/**
 *
 * @author D3--
 */
public interface GameI extends Remote
{
    public boolean isValid(String s) throws Exception;
    public String showScores() throws Exception;
    public void removePlayer(String s) throws Exception;
    public void update(String usr, int id) throws Exception;
    public int getId() throws Exception;
    public int getxfa() throws Exception;
    public int getyfa() throws Exception;
    public boolean isKilled() throws Exception;
}
