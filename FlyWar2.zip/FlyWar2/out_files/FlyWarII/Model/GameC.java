/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FlyWarII.Model;

import java.awt.List;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import FlyWarII.Controller.GameI;
import FlyWarII.Controller.GameI;

/**
 *
 * @author D3--
 */
public class GameC extends UnicastRemoteObject implements GameI
{
    ArrayList<String> usernames = new ArrayList<>();
    ArrayList<Integer> points = new ArrayList<>();
    
    int current_id;
    int current_xfa;
    int current_yfa;
    boolean killed;
    
    Random rnd = new Random();
    
    public GameC() throws Exception
    {
        super();
        killed=false;
        current_id = 0;
        current_xfa = 50;
        current_yfa = 50;
    }
    @Override
    public int getId()
    {
        return current_id;
    }
    @Override
    public int getxfa()
    {
        return current_xfa;
    }
    @Override
    public int getyfa()
    {
        return current_yfa;
    }
    @Override
    public void update(String usr, int id)
    {
        if (id == current_id)
        {
            if (killed == false)
            {
                killed = true;
                class RemindTask extends TimerTask
                    {
                        @Override
                        public void run()
                        {
                            killed = false;
                        }
                    }
                Timer timer = new Timer();
                timer.schedule(new RemindTask(),250);
                points.set(usernames.indexOf(usr), points.get(usernames.indexOf(usr)) + 1);
                current_id++;
                current_xfa = rnd.nextInt(99)+1;
                current_yfa = rnd.nextInt(99)+1;
            }
        }
    }
    @Override
    public boolean isValid(String s)
    {
        if (usernames.indexOf(s)==-1 && s != null)
        {
            usernames.add(s);
            points.add(0);
            return true;
        }
        else
        {
            return false;
        }
    }
    @Override
    public String showScores()
    {
        String temp = "";
        for(int i=0; i<usernames.size();i++)
        {
            temp = temp.concat(usernames.get(i) + ": " + points.get(i) + "\n");
        }
        return temp;
    }
    @Override
    public void removePlayer(String s)
    {
        points.remove(usernames.indexOf(s));
        usernames.remove(s);
        
    }
    public boolean isKilled()
    {
        return killed;
    }
}
