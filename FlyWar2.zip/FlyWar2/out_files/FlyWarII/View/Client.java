/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FlyWarII.View;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author D3--
 */

public class Client extends JFrame
{
    private boolean click_status;
    
    private boolean terminated;
    
    private JTextArea players_status = new JTextArea("");
    private JLabel fly;
    private JLabel killedfly;
    private JLabel bg;
    private JButton exit = new JButton("Exit");
    
    
    
    int fly_area_U;
    int fly_area_B;
    int fly_area_L;
    int fly_area_R;
    
    int current_id;
    
    public Client()
    {     
        ImageIcon myIcon = new ImageIcon("resources/fly.gif");
        fly = new JLabel("", myIcon, JLabel.LEFT);
        ImageIcon myIcon1 = new ImageIcon("resources/killed.png");
        killedfly = new JLabel("", myIcon1, JLabel.LEFT);
        //ImageIcon im = new ImageIcon("bg.jpg");
        //bg = new JLabel("", im, JLabel.CENTER);
        
        click_status = false;
        current_id = 0;
        terminated = false;
        killedfly.setVisible(false);
        
        JPanel VPanel = new JPanel();
        VPanel.setLayout(null);
        this.setPreferredSize(new Dimension (800,600));
        this.pack();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        players_status.setBackground(Color.DARK_GRAY);
        players_status.setForeground(Color.WHITE);
        players_status.setEditable(false);
        
        moveFly(50,50);
        
        VPanel.add(killedfly);
        VPanel.add(players_status);
        VPanel.add(fly);
        VPanel.add(exit);
        //VPanel.add(bg);
        
        exit.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				exitable();
			}
        	
        });
        fly.addMouseListener(new MouseAdapter()
        {  
            public void mouseClicked(MouseEvent e)  
            {
                click_status = true;
            }
        });
        this.addComponentListener(new ComponentAdapter() 
        {  
            public void componentResized(ComponentEvent evt)
            {
                resize();
            }
        });
        this.add(VPanel);
    }
    public void resize()
    {
        fly_area_U = 10;
        fly_area_B = (int) this.getContentPane().getSize().getHeight() - 10;
        fly_area_L = 10;
        fly_area_R = (int) this.getContentPane().getSize().getWidth() - 270;
        
        int height = this.getContentPane().getHeight();
        int width = this.getContentPane().getWidth();
        
        players_status.setBounds(width-260, 10, 250, height-130);
        
        //bg.setBounds(10, 10, width-280, height-20);
        
        exit.setBounds(width-260, height-110, 250, 100);
        
        this.setPreferredSize(new Dimension ((int) this.getSize().getWidth(), (int) this.getSize().getHeight()));
        this.pack();
    }
    public boolean getClickStatus()
    {
        return click_status;
    }
    public void flipClickStatus()
    {
        click_status = false;
    }
    public void makeInvisible()
    {
        killedfly.setVisible(false);
    }
    public void makeVisible()
    {
        killedfly.setVisible(true);
    }
    public void moveFly(int xfact, int yfact)
    {
        int x1 = fly_area_L + (fly_area_R - fly_area_L)*xfact/100 - 25;
        int y1 = fly_area_U + (fly_area_B - fly_area_U)*yfact/100 - 25;
        killedfly.setBounds(x1,y1,50,50);
        fly.setBounds(x1,y1,50,50);
    }
    public String showLoginBox()
    {
        return (String)JOptionPane.showInputDialog("Enter a Unique Username:");
    }
    public void updateScore(String str)
    {
        players_status.setText(str);
    }

    public int getId() {
        return current_id;
    }
    
    public void setId(int new_id)
    {
        current_id = new_id;
    }
    public void exitable()
    {
        terminated = true;
    }
    public boolean isTerminated()
    {
        return terminated;
    }
}
